# HalMeel — Mobile Project & Ideas Planner

HalMeel is a Somali-first Expo / React Native mobile app for saving software-development projects, product ideas, tasks, dates and personal profile details in one place.

## Included in this starter

- Home dashboard with project, idea and open-task counts
- Create, search, inspect, edit and delete projects and ideas
- Track project status: Bilow, Socda, Sugaya, Dhammaystiran
- Create, edit and complete tasks with date, time, priority and optional project name
- Monthly calendar with task indicators and a daily agenda
- Editable profile
- Export/share a JSON backup using the phone's share sheet
- Offline-first local persistence using AsyncStorage
- Somali interface and responsive mobile layout

## Run on Android

1. Install Node.js LTS on the development computer.
2. Extract this ZIP and open a terminal in the `HalMeel-Mobile-App` folder.
3. Install dependencies:

   ```bash
   npm install
   ```

4. Start Expo:

   ```bash
   npx expo start
   ```

5. Scan the QR code with a compatible Expo Go app, or press `a` when an Android emulator is configured. Expo SDK 57 is used to align with the current Expo Go transition period; check the official Expo docs for the latest device compatibility.

## Build an installable Android APK

For a development or production build, install/configure EAS Build and run:

```bash
npx eas-cli@latest login
npx eas-cli@latest build:configure
npx eas-cli@latest build --platform android --profile preview
```

Add an `eas.json` with a `preview` profile using `android.buildType: "apk"` if you specifically need a sideloadable APK.

## Important scope notes

- This is a functional app starter, not an already-built APK.
- Data is saved on the current device only. Export a JSON backup regularly.
- No cloud login/sync, cross-device collaboration, automatic notification scheduling or hosted database is connected yet.
- Before production use, add authentication, backend sync, database access rules, automatic backups and device-notification permissions.

## Suggested next development stage

1. Connect Supabase for account login and private cloud sync.
2. Add real local notifications for task reminders.
3. Add attachments/links and project milestones.
4. Add backup import and Android APK release configuration.

## GitHub → APK automatic build

This project includes `.github/workflows/build-apk.yml`.

### One-time setup

1. Create/sign in to an Expo account.
2. Create an Expo access token (EAS token).
3. In GitHub: **Repository → Settings → Secrets and variables → Actions → New repository secret**.
4. Name the secret exactly: `EXPO_TOKEN`.
5. Paste the Expo access token as the value.

### Build the APK

Push the project to GitHub. The workflow runs on pushes to `main`, or you can run it manually from **GitHub → Actions → Build HalMeel APK → Run workflow**.

The workflow uses Expo EAS to build an Android APK, downloads the generated APK, and uploads it as a GitHub Actions artifact named **HalMeel-Android-APK**.

> The GitHub repository must contain the Expo project files themselves (`package.json`, `app.json`, `App.js`, `eas.json`, and `.github/workflows/build-apk.yml`). Do not upload only the outer ZIP if you want Actions to build it.
